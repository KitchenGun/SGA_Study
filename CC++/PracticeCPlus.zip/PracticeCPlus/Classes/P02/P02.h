#pragma once
#include "../Global/Define/KGDefine.h"

namespace P02Space
{
	void P02(const int argc, const char** args);
}