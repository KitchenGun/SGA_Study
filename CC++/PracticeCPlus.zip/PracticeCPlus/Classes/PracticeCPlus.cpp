#include "P01/P01.h"
#include "P02/P02.h"
#include "P03/P03.h"
#include "P04/P04.h"
//�����Լ�
int main(const int argc, const char** args)
{
	//P01Space::P01(argc, args);
	//P02Space::P02(argc, args);
	//P03Space::P03(argc, args);
	P04Space::P04(argc, args);
	return 0;
}