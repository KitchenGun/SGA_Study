#pragma once
#include "../Global/Define/KGDefine.h"

namespace P04Space
{
	void P04(const int argc, const char** args);
}