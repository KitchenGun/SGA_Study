#pragma once
#include "../Global/Define/KGDefine.h"

namespace P03Space
{
	void P03(const int argc, const char** args);
}