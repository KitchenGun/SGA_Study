#pragma once
#include "../Global/Define/KGDefine.h"

namespace P01Space
{
	void P01(const int argc, const char** args);
}